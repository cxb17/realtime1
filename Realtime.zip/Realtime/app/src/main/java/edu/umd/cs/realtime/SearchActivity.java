package edu.umd.cs.realtime;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import edu.umd.cs.realtime.models.Post;

public class SearchActivity extends AppCompatActivity{
    private ListView searchLV;
    ArrayList<Post> searchResults;
    private ImageView previewImage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        Intent i = getIntent();
        searchResults  = i.getParcelableArrayListExtra("searchResults");

        initializeVariables();
    }


    private void initializeVariables() {
        searchLV = (ListView) findViewById(R.id.searchLv);
        searchLV.setAdapter(new SearchAdapter());
        searchLV.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Post post = searchResults.get(position);
                Intent i1 = new Intent(SearchActivity.this, PostActivity.class);
                i1.putExtra("selectedPost", post);
                startActivity(i1);
            }
        });
    }


    class SearchAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return searchResults.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            Post p = searchResults.get(position);

            convertView = getLayoutInflater().inflate(R.layout.list_cell,null);
            TextView titleTV = (TextView) convertView.findViewById(R.id.titleTv1);
            TextView summaryTV = (TextView) convertView.findViewById(R.id.summaryTv);
            TextView startTV = (TextView) convertView.findViewById(R.id.startTv);
            TextView endTV = (TextView) convertView.findViewById(R.id.endTv);
            TextView locTV = (TextView) convertView.findViewById(R.id.locTv);
            previewImage = (ImageView) convertView.findViewById(R.id.previewImage);
            final ArrayList<String> test = new ArrayList<String>();
            if (Build.VERSION.SDK_INT >= 24) {
                locTV.setText(Html.fromHtml(p.getContent(), Html.FROM_HTML_MODE_LEGACY, new Html.ImageGetter() {
                    @Override
                    public Drawable getDrawable(String source) {
                        test.add(source);
                        return null;
                    }
                }, null));
            } else {
                locTV.setText(Html.fromHtml(p.getContent(), new Html.ImageGetter() {
                    @Override public Drawable getDrawable(String source) {
                        test.add(source);
                        return null;
                    }
                }, null));
            }

            titleTV.setText(p.getTitle());
            summaryTV.setText(p.getSummary());
            startTV.setText(p.getStart());
            endTV.setText(p.getEnd());
            locTV.setText(p.getLocation());
            new SearchActivity.DownloadImageTask().execute(test.get(0));
            return convertView;
        }
    }

    public Drawable drawableFromUrl(String url) throws IOException {
        Bitmap x;

        HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
        connection.connect();
        InputStream input = connection.getInputStream();

        x = BitmapFactory.decodeStream(input);
        return new BitmapDrawable(getResources(),x);
    }

    private class DownloadImageTask extends AsyncTask<String, Void, Drawable> {

        private Exception exception;

        protected Drawable doInBackground(String... urls) {
            Drawable d = null;
            try {
                d = drawableFromUrl(urls[0]);
                d.setBounds(0,0,d.getIntrinsicWidth(),d.getIntrinsicHeight());
            }
            catch (IOException e) {
                exception = e;
            }
            return d;
        }

        protected void onPostExecute(final Drawable d) {
            previewImage.setImageDrawable(d);
        }
    }
}
