package edu.umd.cs.realtime;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.TimeUnit;

import edu.umd.cs.realtime.models.Post;

public class PostActivity extends AppCompatActivity implements CompoundButton.OnCheckedChangeListener,View.OnClickListener, OnMapReadyCallback {
    private DatabaseReference db;
    private FirebaseAuth auth;

    private TextView titleTV, locationTV, categoryTV, endTimeTV, contentTV, timeStatus, businessName, businessPhone, businessEmail;
    //0 is first, 1 is last
    final ArrayList<String> bNames = new ArrayList<String>();
    private View timeBar;
    private Button deleteButton;
    private CheckBox favoriteButton;
    private Post post;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post);

        //Include all variables to set their valureaes.
        initializeVariables();
        //Add post data to variables and handle the visibility of the delete button.
        loadPostData();

        MapFragment mapFragment = (MapFragment) getFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

    }

    private void initializeVariables() {
        bNames.add("");
        bNames.add("");
        titleTV = (TextView) findViewById(R.id.titleTv2);
        locationTV = (TextView) findViewById(R.id.locationTv);
        categoryTV = (TextView) findViewById(R.id.categoryTv);
        endTimeTV = (TextView) findViewById(R.id.endTimeTv);
        contentTV = (TextView) findViewById(R.id.contentTv);
        timeStatus = (TextView) findViewById(R.id.time_status);
        businessName = (TextView) findViewById(R.id.businessName);
        businessPhone = (TextView) findViewById(R.id.businessPhone);
        businessEmail = (TextView) findViewById(R.id.businessEmail);
        deleteButton = (Button) findViewById(R.id.deleteBtn);
        favoriteButton = (CheckBox) findViewById(R.id.favBtn);
        timeBar = (View) findViewById(R.id.rectangle_at_the_top);

        db = FirebaseDatabase.getInstance().getReference();
        auth = FirebaseAuth.getInstance();
        contentTV.setMovementMethod(new ScrollingMovementMethod());
        deleteButton.setOnClickListener(this);

    }

    private boolean isOwner(String pid) {
        return auth.getCurrentUser().getUid().equals(pid);
    }

    private void loadPostData() {
        Intent i = getIntent();
        post = i.getExtras().getParcelable("selectedPost");
        String[] categories = Post.getCategories();

        //Remove the delete button if current user is not the owner.
        if (!isOwner(post.getPid())) {
            deleteButton.setVisibility(View.GONE);
        }

        Calendar currentTime = Calendar.getInstance();
        String[] splitStart = post.getStart().split(" ");
        String[] splitEnd = post.getEnd().split(" ");
        String[] sTimeSplit = splitStart[4].split(":");
        String[] eTimeSplit = splitEnd[4].split(":");
        Calendar startTime = Calendar.getInstance();
        startTime.set(Integer.parseInt(splitStart[3]),getMonth(splitStart[1]),Integer.parseInt(splitStart[2]),Integer.parseInt(sTimeSplit[0]),Integer.parseInt(sTimeSplit[1]),Integer.parseInt(sTimeSplit[2]));
        Calendar endTime = Calendar.getInstance();
        endTime.set(Integer.parseInt(splitEnd[3]),getMonth(splitEnd[1]),Integer.parseInt(splitEnd[2]),Integer.parseInt(eTimeSplit[0]),Integer.parseInt(eTimeSplit[1]),Integer.parseInt(eTimeSplit[2]));
        //event has not started yet
        if (currentTime.compareTo(startTime) < 0) {
            long startMill = startTime.getTimeInMillis();
            long currMill = currentTime.getTimeInMillis();
            long timeUntil = startMill - currMill;
            long days = TimeUnit.MILLISECONDS.toDays(timeUntil);
            timeUntil -= TimeUnit.DAYS.toMillis(days);
            long hours = TimeUnit.MILLISECONDS.toHours(timeUntil);
            timeUntil -= TimeUnit.HOURS.toMillis(hours);
            long minutes = TimeUnit.MILLISECONDS.toMinutes(timeUntil);
            timeUntil -= TimeUnit.MINUTES.toMillis(minutes);
            long seconds = TimeUnit.MILLISECONDS.toSeconds(timeUntil);
            timeStatus.setText("Event Starts in "+days+" Days, "+hours+" Hours, "+minutes+" Minutes, and "+seconds+" Seconds");
            timeBar.setBackgroundColor(getResources().getColor(R.color.beforeYellow));
        }
        //event has not ended yet
        else if (currentTime.compareTo(endTime) < 0) {
            long endMill = endTime.getTimeInMillis();
            long currMill = currentTime.getTimeInMillis();
            long timeUntil = endMill - currMill;
            long days = TimeUnit.MILLISECONDS.toDays(timeUntil);
            timeUntil -= TimeUnit.DAYS.toMillis(days);
            long hours = TimeUnit.MILLISECONDS.toHours(timeUntil);
            timeUntil -= TimeUnit.HOURS.toMillis(hours);
            long minutes = TimeUnit.MILLISECONDS.toMinutes(timeUntil);
            timeUntil -= TimeUnit.MINUTES.toMillis(minutes);
            long seconds = TimeUnit.MILLISECONDS.toSeconds(timeUntil);
            timeStatus.setText("Event Ends in "+days+" Days, "+hours+" Hours, "+minutes+" Minutes, and "+seconds+" Seconds");
            timeBar.setBackgroundColor(getResources().getColor(R.color.progressGreen));
        }
        //event has ended
        else {
            timeStatus.setText("EVENT HAS ENDED");
            timeBar.setBackgroundColor(getResources().getColor(R.color.overRed));
        }
        timeBar.bringToFront();
        timeStatus.bringToFront();

        titleTV.setText(post.getTitle());
        locationTV.setText(post.getLocation());
        categoryTV.setText(categories[post.getCategory()]);
        endTimeTV.setText(post.getEnd());

        //REAL, include when image uploading is fixed
        final ArrayList<String> test = new ArrayList<String>();
        if (Build.VERSION.SDK_INT >= 24) {
            contentTV.setText(Html.fromHtml(post.getContent(), Html.FROM_HTML_MODE_LEGACY, new Html.ImageGetter() {
                @Override
                public Drawable getDrawable(String source) {
                    test.add(source);
                    return null;
                }
            }, null));
        } else {
            contentTV.setText(Html.fromHtml(post.getContent(), new Html.ImageGetter() {
                @Override public Drawable getDrawable(String source) {
                    test.add(source);
                    return null;
                }
            }, null));
        }
        new DownloadImageTask().execute(test.get(0));

        setFavoriteButton();
        favoriteButton.setOnCheckedChangeListener(this);

        DatabaseReference pubInfo = db.child("users").child(post.getPid());
        pubInfo.child("cellPhone").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                businessPhone.setText("Cell Phone: "+dataSnapshot.getValue().toString());
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        pubInfo.child("email").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                businessEmail.setText("Email: "+dataSnapshot.getValue().toString());
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        pubInfo.child("firstName").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                bNames.set(0,dataSnapshot.getValue().toString());
                businessName.setText("Name: "+dataSnapshot.getValue().toString()+" "+bNames.get(1));
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        pubInfo.child("lastName").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                bNames.set(1,dataSnapshot.getValue().toString());
                businessName.setText("Name: "+bNames.get(0)+" "+dataSnapshot.getValue().toString());
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }



    private void setFavoriteButton() {
        String uid = auth.getCurrentUser().getUid();
        DatabaseReference favRef = db.child("favorites").child(uid).child(post.getId());

        ValueEventListener favsListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Boolean res = (Boolean) dataSnapshot.getValue();

                if (res != null) {
                    favoriteButton.setChecked(true);
                }


            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        };

        favRef.addListenerForSingleValueEvent(favsListener);
    }

    private void favorite() {
        String uid = auth.getCurrentUser().getUid();
        DatabaseReference favRef = db.child("favorites").child(uid).child(post.getId());
        favRef.setValue(true);
    }

    private void unfavorite() {
        String uid = auth.getCurrentUser().getUid();
        DatabaseReference favRef = db.child("favorites").child(uid).child(post.getId());
        favRef.removeValue();
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        // Add a marker in Sydney, Australia,
        // and move the map's camera to the same location.
        LatLng loc = getLocationFromAddress(this, post.getLocation());
        Log.e("LOCATION!!!!", ""+post.getLocation());
        googleMap.addMarker(new MarkerOptions().position(loc).title("Event Location"));
        googleMap.moveCamera( CameraUpdateFactory.newLatLngZoom(loc , 14.0f) );
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if (isChecked) {
            favorite();
        } else {
            unfavorite();
        }
    }


    private void delete() {
        DatabaseReference postRef = db.child("posts").child(post.getId());
        postRef.removeValue();
    }


    @Override
    public void onClick(View v) {
        if (v == deleteButton) {
            Log.d("DEL", "Clicked");
            delete();
            startActivity(new Intent(PostActivity.this, MainActivity.class));
        }
    }

    private int getMonth (String month) {
        month = month.toLowerCase();
        if ("january".contains(month)) {
            return 0;
        }
        else if ("february".contains(month)) {
            return 1;
        }
        else if ("march".contains(month)) {
            return 2;
        }
        else if ("april".contains(month)) {
            return 3;
        }
        else if ("may".contains(month)) {
            return 4;
        }
        else if ("june".contains(month)) {
            return 5;
        }
        else if ("july".contains(month)) {
            return 6;
        }
        else if ("august".contains(month)) {
            return 7;
        }
        else if ("september".contains(month)) {
            return 8;
        }
        else if ("october".contains(month)) {
            return 9;
        }
        else if ("november".contains(month)) {
            return 10;
        }
        else if ("december".contains(month)) {
            return 11;
        }
        else {
            return -1;
        }
    }

    public LatLng getLocationFromAddress(Context context, String strAddress) {

        Geocoder coder = new Geocoder(context);
        List<Address> address;
        LatLng p1 = null;

        try {
            // May throw an IOException
            address = coder.getFromLocationName(strAddress, 5);
            if (address == null) {
                return null;
            }
            Address location = address.get(0);
            location.getLatitude();
            location.getLongitude();

            p1 = new LatLng(location.getLatitude(), location.getLongitude() );

        } catch (IOException ex) {

            ex.printStackTrace();
        }

        return p1;
    }

    public Drawable drawableFromUrl(String url) throws IOException {
        Bitmap x;

        HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
        connection.connect();
        InputStream input = connection.getInputStream();

        x = BitmapFactory.decodeStream(input);
        return new BitmapDrawable(getResources(),x);
    }

    private class DownloadImageTask extends AsyncTask <String, Void, Drawable>{

        private Exception exception;

        protected Drawable doInBackground(String... urls) {
            Drawable d = null;
            try {
                d = drawableFromUrl(urls[0]);
                d.setBounds(0,0,d.getIntrinsicWidth(),d.getIntrinsicHeight());
            }
            catch (IOException e) {
                exception = e;
            }
            return d;
        }

        protected void onPostExecute(final Drawable d) {
            if (Build.VERSION.SDK_INT >= 24) {
                contentTV.setText(Html.fromHtml(post.getContent(), Html.FROM_HTML_MODE_LEGACY, new Html.ImageGetter() {
                    @Override
                    public Drawable getDrawable(String source) {
                        return d;
                    }
                }, null));
            } else {
                contentTV.setText(Html.fromHtml(post.getContent(), new Html.ImageGetter() {
                    @Override public Drawable getDrawable(String source) {
                        return d;
                    }
                }, null));
            }
        }
    }
}
