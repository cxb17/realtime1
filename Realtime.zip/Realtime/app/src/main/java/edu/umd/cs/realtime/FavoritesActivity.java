package edu.umd.cs.realtime;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import edu.umd.cs.realtime.models.Post;

public class FavoritesActivity extends AppCompatActivity {
    private DatabaseReference db;
    private FirebaseAuth auth;
    private ListView favsLV;
    final ArrayList<Post> posts = new ArrayList<Post>();
    private ImageView previewImage;
    private Post currImagePost;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorites);

        //Include all variables to set their valureaes.
        initializeVariables();

        loadFavorites();

    }

    private void initializeVariables() {

        db = FirebaseDatabase.getInstance().getReference();
        auth = FirebaseAuth.getInstance();
        favsLV = (ListView) findViewById(R.id.postsLv);

    }

    private void loadFavorites() {
        String uid = auth.getCurrentUser().getUid();
        final DatabaseReference postsRef = db.child("posts");
        DatabaseReference favRef = db.child("favorites").child(uid);
        favRef.addValueEventListener(new ValueEventListener() {
            @Override
            //Found favorites
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot postSnapshot: dataSnapshot.getChildren()) {
                    final DatabaseReference favInPosts = postsRef.child(postSnapshot.getKey());
                    //check if favorite still exists
                    favInPosts.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            if (dataSnapshot != null) {
                                int index = posts.size();
                                posts.add(new Post());
                                getPostFromRef(favInPosts, index);
                            }
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {

                        }
                    });
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }

    public void doAdapter () {
        PostAdapter pAdapter = new PostAdapter(this, posts);
        favsLV.setAdapter(pAdapter);
        favsLV.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Post post = (Post) parent.getItemAtPosition(position);
                Intent i = new Intent(FavoritesActivity.this, PostActivity.class);
                i.putExtra("selectedPost", post);
                startActivity(i);
            }
        });
    }

    public void getPostFromRef (DatabaseReference ref, final int index) {
        //title
        ref.child("title").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                posts.get(index).setTitle((String)dataSnapshot.getValue());
                doAdapter();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        //category
        ref.child("category").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                posts.get(index).setCategory(Integer.parseInt(dataSnapshot.getValue().toString()));
                doAdapter();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        //content
        ref.child("content").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                posts.get(index).setContent((String)dataSnapshot.getValue());
                doAdapter();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        //summary
        ref.child("summary").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                posts.get(index).setSummary((String)dataSnapshot.getValue());
                doAdapter();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        //createdAt
        ref.child("createdAt").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                posts.get(index).setCreatedAt(Long.parseLong(dataSnapshot.getValue().toString()));
                doAdapter();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        //id
        ref.child("id").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                posts.get(index).setId((String)dataSnapshot.getValue());
                doAdapter();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        //end
        ref.child("end").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                posts.get(index).setEnd((String)dataSnapshot.getValue());
                doAdapter();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        //start
        ref.child("start").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                posts.get(index).setStart((String)dataSnapshot.getValue());
                doAdapter();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        //location
        ref.child("location").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                posts.get(index).setLocation((String)dataSnapshot.getValue());
                doAdapter();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        //pid
        ref.child("pid").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                posts.get(index).setPid((String)dataSnapshot.getValue());
                doAdapter();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    private class PostAdapter extends ArrayAdapter<Post> {

        private Context mContext;
        private ArrayList<Post> ppp;

        public PostAdapter(Context context, ArrayList<Post> list) {
            super(context, 0 , list);
            mContext = context;
            ppp = list;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View v = convertView;

            if (v == null) {
                v = LayoutInflater.from(mContext).inflate(R.layout.list_cell,parent,false);
            }

            Post model = ppp.get(position);

            TextView titleTV = (TextView) v.findViewById(R.id.titleTv1);
            TextView summaryTV = (TextView) v.findViewById(R.id.summaryTv);
            TextView startTV = (TextView) v.findViewById(R.id.startTv);
            TextView endTV = (TextView) v.findViewById(R.id.endTv);
            TextView locTV = (TextView) v.findViewById(R.id.locTv);
            previewImage = (ImageView) v.findViewById(R.id.previewImage);
            final ArrayList<String> test = new ArrayList<String>();
            if (Build.VERSION.SDK_INT >= 24) {
                locTV.setText(Html.fromHtml(model.getContent(), Html.FROM_HTML_MODE_LEGACY, new Html.ImageGetter() {
                    @Override
                    public Drawable getDrawable(String source) {
                        test.add(source);
                        return null;
                    }
                }, null));
            } else {
                locTV.setText(Html.fromHtml(model.getContent(), new Html.ImageGetter() {
                    @Override public Drawable getDrawable(String source) {
                        test.add(source);
                        return null;
                    }
                }, null));
            }

            titleTV.setText(model.getTitle());
            summaryTV.setText(model.getSummary());
            startTV.setText(model.getStart());
            endTV.setText(model.getEnd());
            locTV.setText(model.getLocation());
            new FavoritesActivity.DownloadImageTask().execute(test.get(0));

            return v;
        }
    }

    public Drawable drawableFromUrl(String url) throws IOException {
        Bitmap x;

        HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
        connection.connect();
        InputStream input = connection.getInputStream();

        x = BitmapFactory.decodeStream(input);
        return new BitmapDrawable(getResources(),x);
    }

    private class DownloadImageTask extends AsyncTask<String, Void, Drawable> {

        private Exception exception;

        protected Drawable doInBackground(String... urls) {
            Drawable d = null;
            try {
                d = drawableFromUrl(urls[0]);
                d.setBounds(0,0,d.getIntrinsicWidth(),d.getIntrinsicHeight());
            }
            catch (IOException e) {
                exception = e;
            }
            return d;
        }

        protected void onPostExecute(final Drawable d) {
            previewImage.setImageDrawable(d);
        }
    }
}
