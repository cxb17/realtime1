package edu.umd.cs.realtime;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.InputType;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class SettingsActivity extends AppCompatActivity {
    private DatabaseReference db;
    private FirebaseAuth auth;
    private TextView fname, lname, email, cell, address, password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        initializeVariables();
    }

    private void initializeVariables() {
        db = FirebaseDatabase.getInstance().getReference();
        auth = FirebaseAuth.getInstance();
        final String uid = auth.getCurrentUser().getUid();

        fname = (TextView)findViewById(R.id.fnameSettings);
        lname = (TextView)findViewById(R.id.lnameSettings);
        email = (TextView)findViewById(R.id.emailSettings);
        cell = (TextView)findViewById(R.id.cellphoneSettings);
        address = (TextView)findViewById(R.id.addressSettings);
        password = (TextView)findViewById(R.id.passwordSettings);


        db.child("users").child(uid).child("firstName").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                fname.setText("First Name: "+snapshot.getValue().toString());
            }

            @Override
            public void onCancelled(DatabaseError firebaseError) {

            }
        });
        fname.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final EditText edittext = new EditText(SettingsActivity.this);
                edittext.setText(fname.getText().toString().split(": ")[1]);
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(SettingsActivity.this);
                alertDialog.setTitle("Settings");
                alertDialog.setMessage("Edit First Name");
                alertDialog.setView(edittext);
                alertDialog.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        db.child("users").child(uid).child("firstName").setValue(edittext.getText().toString());
                    }
                });

                alertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {

                    }
                });

                alertDialog.show();
            }
        });

        db.child("users").child(uid).child("lastName").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                lname.setText("Last Name: "+snapshot.getValue().toString());
            }

            @Override
            public void onCancelled(DatabaseError firebaseError) {

            }
        });
        lname.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final EditText edittext = new EditText(SettingsActivity.this);
                edittext.setText(lname.getText().toString().split(": ")[1]);
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(SettingsActivity.this);
                alertDialog.setTitle("Settings");
                alertDialog.setMessage("Edit Last Name");
                alertDialog.setView(edittext);
                alertDialog.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        db.child("users").child(uid).child("lastName").setValue(edittext.getText().toString());
                    }
                });

                alertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {

                    }
                });

                alertDialog.show();
            }
        });

        db.child("users").child(uid).child("email").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                email.setText("Email: "+snapshot.getValue().toString());
            }

            @Override
            public void onCancelled(DatabaseError firebaseError) {

            }
        });
        email.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final EditText edittext = new EditText(SettingsActivity.this);
                edittext.setText(email.getText().toString().split(": ")[1]);
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(SettingsActivity.this);
                alertDialog.setTitle("Settings");
                alertDialog.setMessage("Edit Email");
                alertDialog.setView(edittext);
                alertDialog.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        db.child("users").child(uid).child("email").setValue(edittext.getText().toString());
                    }
                });

                alertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {

                    }
                });

                alertDialog.show();
            }
        });

        db.child("users").child(uid).child("cellPhone").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                cell.setText("Cell Phone: "+snapshot.getValue().toString());
            }

            @Override
            public void onCancelled(DatabaseError firebaseError) {

            }
        });
        cell.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final EditText edittext = new EditText(SettingsActivity.this);
                edittext.setText(cell.getText().toString().split(": ")[1]);
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(SettingsActivity.this);
                alertDialog.setTitle("Settings");
                alertDialog.setMessage("Edit Cell Phone Number");
                alertDialog.setView(edittext);
                alertDialog.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        db.child("users").child(uid).child("cellPhone").setValue(edittext.getText().toString());
                    }
                });

                alertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {

                    }
                });

                alertDialog.show();
            }
        });

        db.child("users").child(uid).child("address").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                address.setText("Address: "+snapshot.getValue().toString());
            }

            @Override
            public void onCancelled(DatabaseError firebaseError) {

            }
        });
        address.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final EditText edittext = new EditText(SettingsActivity.this);
                edittext.setText(address.getText().toString().split(": ")[1]);
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(SettingsActivity.this);
                alertDialog.setTitle("Settings");
                alertDialog.setMessage("Edit Address");
                alertDialog.setView(edittext);
                alertDialog.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        db.child("users").child(uid).child("address").setValue(edittext.getText().toString());
                    }
                });

                alertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {

                    }
                });

                alertDialog.show();
            }
        });
        password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(SettingsActivity.this);
                LinearLayout layout = new LinearLayout(SettingsActivity.this);
                layout.setOrientation(LinearLayout.VERTICAL);
                final EditText editNew = new EditText(SettingsActivity.this);
                editNew.setHint("Enter New Password");
                editNew.setInputType(InputType.TYPE_TEXT_VARIATION_PASSWORD);
                layout.addView(editNew);
                final EditText editNewConfirm = new EditText(SettingsActivity.this);
                editNewConfirm.setHint("Confirm New Password");
                editNewConfirm.setInputType(InputType.TYPE_TEXT_VARIATION_PASSWORD);
                layout.addView(editNewConfirm);
                alertDialog.setTitle("Password");
                alertDialog.setMessage("Change Password");
                alertDialog.setView(layout);
                alertDialog.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        if (editNew.getText().toString().length()==0 || editNewConfirm.getText().toString().length()==0) {
                            Toast.makeText(SettingsActivity.this, "Fields cannot be blank", Toast.LENGTH_LONG).show();
                        }
                        else if (editNew.getText().toString().equals(editNewConfirm.getText().toString())) {
                            auth.getCurrentUser().updatePassword(editNew.getText().toString());
                            Toast.makeText(SettingsActivity.this, "Password successfully changed", Toast.LENGTH_LONG).show();
                        }
                        else {
                            Toast.makeText(SettingsActivity.this, "The passwords do not match", Toast.LENGTH_LONG).show();
                        }
                    }
                });

                alertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {

                    }
                });

                alertDialog.show();
            }
        });
    }

}
